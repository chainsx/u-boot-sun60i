
DIR=$(busybox dirname $0)
source $DIR/Performance_test.conf

TEST_TARGET=''

get_target()
{
	df | grep emulated >> /dev/null 
	if [ $? -eq 0 ]; then
		TEST_TARGET="/data"
	else
		TEST_TARGET="/mnt/sdcard"
	fi
}

if [ x$1 != x"" ];then
	TEST_TARGET=$1
else
	get_target
fi

TEST_DIR=${TEST_TARGET}/test_tmp
mkdir -p $TEST_DIR

cat << EOF > $DIR/scripts/stable_test_param
log path=${TEST_DIR}/${RESULT},showlevel=3,storelevel=2
dg colordata
file path=${TEST_DIR}/${FILE},pcnttototal=95,needremove
	open create,mod=0666
	rw wr,gettime,fsync
	close
	
file path=${TEST_DIR}/${FILE},size=${FileSize}
	#˳��д
	loop count=3
	open create,mod=0666
	rw wr,interval=1,gettime,fsync,show
	close
	loopend
	
	#˳���
	loop count=3
		#�������
	cleanmem
	open mod=0666
	rw rd,interval=1,gettime,show
	close
	loopend

	#�����
	loop count=3
		#�������
	cleanmem
	open mod=0666,direct
	rw rd,random,interval=1,gettime,show,testtime=$MaxRandTestTime,testcount=${FileSize}
	close	
	loopend
	
	#���д
	loop count=3
	open mod=0666,direct
	rw wr,random,interval=1,gettime,show,testtime=$MaxRandTestTime,testcount=${FileSize}
	close
	loopend
	
	unlink
EOF

echo "Writing fulldisk file, please wait..."
$DIR/iosimu $DIR/scripts/stable_test_param