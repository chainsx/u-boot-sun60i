
DIR=$(busybox dirname $0)
TEST_TARGET=''

get_target()
{
	df | grep emulated >> /dev/null 
	if [ $? -eq 0 ]; then
		TEST_TARGET="/data"
	else
		TEST_TARGET="/mnt/sdcard"
	fi
}

if [ x$1 != x"" ];then
	TEST_TARGET=$1
else
	get_target
fi

TEST_DIR=${TEST_TARGET}/test_tmp
rm -rf ${TEST_DIR}
mkdir -p $TEST_DIR

cd $TEST_DIR


cat << EOF > $DIR/scripts/small_files_write

log path=/dev/small_files_write.log,showlevel=2,storelevel=4

dg colordata

file path=iosimu_fill,size=256M,needremove
	open create,mod=0666
	rw wr,gettime
	close

file prefix=iosimu_test,size=4K,totalsize=32M,needremove,gettime
	open create,mod=0666
	rw wr,gettime
	close
EOF

$DIR/iosimu $DIR/scripts/small_files_write
#rm -rf iosimu_test*