#!/bin/sh


mount /dev/sda5 /mnt/
mkdir /mnt/1
mkdir /mnt/2
mkdir /mnt/3
mkdir /mnt/4
mkdir /mnt/5

rm -rf /mnt/1/*
rm -rf /mnt/2/*
rm -rf /mnt/3/*
rm -rf /mnt/4/*
rm -rf /mnt/5/*

rwcheck -d /mnt/1/ -b 128K -t 999999 -e 2G -p 50 & rwcheck -d /mnt/2/ -b 128K -t 999999 -e 2G -p 50 & rwcheck -d /mnt/3/ -b 128K -t 999999 -e 2G -p 50 & rwcheck -d /mnt/4/ -b 128K -t 999999 -e 2G -p 50 & rwcheck -d /mnt/5/ -b 128K -t 999999 -e 2G -p 50 &