#!/bin/sh

mkdir /mnt/ufs/
./fio -name=Seq_Write_IOPS_Test -group_reporting  -rw=write -bs=1M -directory=/mnt/ufs/ -size=2G  -io_size=2G -nrfiles=1 -direct=1 -thread  | grep "WRITE: bw=" && rm /mnt/ufs/Seq_Write_IOPS_Test*
./fio -name=Seq_Read_IOPS_Test -group_reporting  -rw=read -bs=1M  -directory=/mnt/ufs/ -size=2G  -io_size=2G -nrfiles=1 -thread  | grep "READ: bw=" && rm /mnt/ufs/Seq_Read_IOPS_Test*
./fio -name=Rand_Write_IOPS_Test -group_reporting  -rw=randwrite -bs=4K -numjobs=8 -directory=/mnt/ufs -size=2G  -io_size=64M -nrfiles=1 -direct=1 -thread | grep "write: IOPS=" && rm /mnt/ufs/Rand_Write_IOPS_Test*
./fio -name=Rand_Read_IOPS_Test -group_reporting  -rw=randread -bs=4K -numjobs=8 -directory=/mnt/ufs -size=2G  -io_size=64M -nrfiles=1 -direct=1 -thread | grep "read: IOPS=" && rm /mnt/ufs/Rand_Read_IOPS_Test*
