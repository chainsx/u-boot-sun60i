#!/bin/sh
i=0
while [ 1 -eq 1 ]; do
	echo 5000 > /sys/power/sunxi_debug/time_to_wakeup_ms
	echo mem > /sys/power/state
	sleep 5
	i=$(busybox expr $i + 1)
	echo past total cycle test: $i times done.
done
