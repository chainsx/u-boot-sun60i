echo 8 > /proc/sys/kernel/printk
echo N > /sys/module/printk/parameters/console_suspend
echo Y > /sys/module/kernel/parameters/initcall_debug
echo 1 > /sys/power/pm_debug_messages
echo 0 > /sys/power/pm_print_times

i=0

if [ 1 -ne $# ] ;then
	echo "format: test_standby.sh 1000"
	exit 1
fi

memtester 100M > /dev/null &
echo test > test.txt
i=0
while [ $1 -ne $i ]; do
	echo 3 > /proc/sys/vm/drop_caches
	cat test.txt
	let "i++"
	echo +15 > /sys/class/rtc/rtc0/wakealarm; echo mem > /sys/power/state
	sleep 2
	i=$(busybox expr $i + 1)
	echo past total cycle test: $i times done.	
done
