#!/bin/bash

echo "=========Android: SD: start loop write 1G data=========="

while true; do
	echo 3 > /proc/sys/vm/drop_caches
	time dd if=/dev/block/mmcblk0 of=/dev/block/mmcblk1 bs=4K count=16K conv=fsync
done
