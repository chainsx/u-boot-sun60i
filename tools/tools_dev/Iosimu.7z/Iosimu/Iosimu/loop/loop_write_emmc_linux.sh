#!/bin/bash

echo "=========Linux: eMMC: start loop write 1G data=========="

while true; do
	time dd if=/dev/zero of=/dev/block/mmcblk0p1 bs=4096 count=262144
	sync
done
