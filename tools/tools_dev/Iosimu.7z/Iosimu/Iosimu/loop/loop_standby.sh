#!/bin/sh

#echo 8 > /proc/sys/kernel/printk
#echo N > /sys/module/printk/parameters/console_suspend
#echo Y > /sys/module/kernel/parameters/initcall_debug
#echo 1 > /sys/power/pm_print_times
while [ 1 -eq 1 ]; do
	echo 2000 > /sys/module/pm/parameters/time_to_wakeup_ms
	echo mem > /sys/power/state
	sleep 5
done
