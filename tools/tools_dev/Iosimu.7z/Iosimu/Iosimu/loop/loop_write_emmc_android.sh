#!/bin/bash

echo "=========Android: eMMC: start loop write 1G data=========="

while true; do
	echo 3 > /proc/sys/vm/drop_caches
	time dd if=/dev/zero of=/dev/block/mmcblk0p17 bs=4K count=16K seek=256K conv=fsync
done
