
DIR=$(busybox dirname $0)
source $DIR/Performance_test.conf

TEST_TARGET=''

get_target()
{
	df | grep emulated >> /dev/null 
	if [ $? -eq 0 ]; then
		TEST_TARGET="/data"
	else
		TEST_TARGET="/mnt/sdcard"
	fi
}

if [ x$1 != x"" ];then
	TEST_TARGET=$1
else
	get_target
fi

TEST_DIR=${TEST_TARGET}/test_tmp
mkdir -p $TEST_DIR

cd $TEST_DIR

$DIR/iosimu $DIR/scripts/fulldisk_seq_write ${TEST_TARGET}

rm -rf iosimu_test*

cat << EOF > $DIR/scripts/performance_test_param
log path=${TEST_DIR}/${RESULT},showlevel=3,storelevel=2

dg colordata
file path=${TEST_DIR}/${FILE},size=${FileSize},needremove
	#˳��д
	loop count=$LoopCount
		open create,mod=0666
		rw wr,interval=1,gettime,fsync,show
		close
	loopend
	
	#˳���
	loop count=$LoopCount
		#�������
		cleanmem
		open mod=0666
		rw rd,interval=1,gettime,show
		close
	loopend

	#�����
	loop count=$LoopCount
		#�������
		cleanmem
		open mod=0666,direct
		rw rd,random,interval=1,gettime,show,testtime=$MaxRandTestTime,testcount=${FileSize}
		close	
	loopend
	
	#���д
	loop count=$LoopCount
		open mod=0666,direct
		rw wr,random,interval=1,gettime,show,testtime=$MaxRandTestTime,testcount=${FileSize}
		close
	loopend
	
	unlink
EOF

$DIR/iosimu $DIR/scripts/performance_test_param
